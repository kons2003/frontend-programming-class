let a = [];

for (let i = 0; i < 20; i++) {
    a.push(Math.floor(Math.random() * 20) + 1);
}

console.log(a);