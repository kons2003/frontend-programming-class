let persons = [
    {name:"홍길동", age:16},
    {name:"임꺽정", age:19}
];

let p1 = persons[0];
let p2 = persons[1];
let a = [p1, p2];