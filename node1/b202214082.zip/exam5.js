let persons = { name: "홍길동", age:16};

let a = [persons, persons];